#!/bin/bash
name=""
echo -n "ingresa tu nombre"
read name
echo "Hola ${name}"
